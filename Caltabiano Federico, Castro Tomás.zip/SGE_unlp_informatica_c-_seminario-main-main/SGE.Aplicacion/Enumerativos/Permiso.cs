﻿namespace SGE.Aplicacion;

public enum Permiso
{
    ExpedienteAlta,
    ExpedienteBaja,
    ExpedienteModificacion,
    TramiteAlta,
    TramiteBaja,
    TramiteModificacion,
}
