﻿namespace SGE.Aplicacion;

public enum EtiquetaTramite
{
    EscritoPresentado,
    PaseAEstudio,
    Despacho,
    Resolucion,
    Notificacion,
    PaseAlArchivo,
}
