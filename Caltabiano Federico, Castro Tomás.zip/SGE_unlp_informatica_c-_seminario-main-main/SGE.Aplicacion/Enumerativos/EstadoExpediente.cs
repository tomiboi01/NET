﻿namespace SGE.Aplicacion;
public enum EstadoExpediente
{
    RecienIniciado,
    ParaResolver,
    ConResolucion,
    EnNotificacion,
    Finalizado

}
